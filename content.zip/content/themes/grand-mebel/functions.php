<?php
/**
 * Функции шаблона (function.php)
 * @package WordPress
 * @subpackage your-grand-mebel-template-3
 */

require_once (get_template_directory() . DIRECTORY_SEPARATOR . 'functions' . DIRECTORY_SEPARATOR . 'register_product_category_taxonomy.php');
require_once (get_template_directory() . DIRECTORY_SEPARATOR . 'functions' . DIRECTORY_SEPARATOR . 'register_product_post_type.php');
flush_rewrite_rules();

add_theme_support('title-tag');

require_once('WP_Bootstrap_Navwalker.php');
register_nav_menus( array(
    'header_main' => __('Header Main Menu', 'grand-mebel'),
    'footer_main' => __('Footer Main Menu', 'grand-mebel'),
    'footer_products' => __('Footer Products Menu', 'grand-mebel')
) );

add_theme_support('post-thumbnails');
set_post_thumbnail_size(250, 150);
add_image_size('big-thumb', 400, 400, true);

register_sidebar(array(
	'name' => 'Сайдбар',
	'id' => "sidebar",
	'description' => 'Обычная колонка в сайдбаре',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget' => "</div>\n",
	'before_title' => '<span class="widgettitle">',
	'after_title' => "</span>\n",
));

if (!function_exists('pagination')) {
	function pagination() {
		global $wp_query;
		$big = 999999999;
		$links = paginate_links(array(
			'base' => str_replace($big,'%#%',esc_url(get_pagenum_link($big))),
			'format' => '?paged=%#%',
			'current' => max(1, get_query_var('paged')),
			'type' => 'array',
			'prev_text'    => 'Назад',
	    	'next_text'    => 'Вперед',
			'total' => $wp_query->max_num_pages,
			'show_all'     => false,
			'end_size'     => 15,
			'mid_size'     => 15,
			'add_args'     => false,
			'add_fragment' => '',
			'before_page_number' => '',
			'after_page_number' => ''
		));
	 	if( is_array( $links ) ) {
		    echo '<ul class="pagination">';
		    foreach ( $links as $link ) {
		    	if ( strpos( $link, 'current' ) !== false ) echo "<li class='active'>$link</li>";
		        else echo "<li>$link</li>"; 
		    }
		   	echo '</ul>';
		 }
	}
}